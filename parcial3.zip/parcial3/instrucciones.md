Instrucciones:

- Instalar la última version de Node.js en el sistema.
- Instalar MongoDB Community Server de esta url:
  https://www.mongodb.com/download-center?jmp=tutorials#community

* Creación de la base de datos en MongoDB (Sin MongoDB compass):

- Ir a la carpeta C:\Program Files\MongoDB\Server\<numero de version>\bin y ejecutar el programa mongo.exe.

- En la ventana de comando escribir "use <nombre de la base de datos>" (Ejemplo: use crud-app), para
  crear la base de datos si no ha sido creada, aparecerá el mensaje "switched to crud-app".

- Para crear una colección en la base de datos escribir: db.createCollection(<nombre de la coleccion>).
  Ejemplo: db.createCollection("usuarios"). Escribir el comando: show collections, para ver que colecciones tiene la base de datos.

- Para insertar manualmente un registro en la coleccion, ejecutar el comando "db.<nombre de la coleccion>.insert()" y pasar como argumento un objeto que se quiera almacenar.

Ejemplo: db.clientes.insert({"nombre":"John","apellido":"Doe","cedula":"9-999-9999"})

- Para ver los objetos dentro de la coleccion ejecutar el comando "db.<nombre de la coleccion>.find()".
  Ejemplo: db.clientes.find()

* Configuracion del ambiente de desarrollo:

- Crear una carpeta para guardar los archivos del projecto.

- Abrir una linea de comando dentro de la carpeta del proyecto y ejecutar el
  comando: "npm init". Luego se muestran los pasos para generar el archivo package.json. Se debe tener Node.js instalado para que funcione.

Luego de generar el archivo package.json, abrir la linea de comando e instalar
Express.js, Ejs, Angular, Mongoose, Body-parser, Nodemon, y Cors con npm, ejecutando el comando:
npm <nombre del paquete> install --save.

Ejemplos:
"npm install express --save"
"npm install @angular/cli --save"
"npm install mongoose --save"

Luego que finalice la instalación deberan aparecer las dependencias en el archivo package.json bajo la seccion "dependencies". No confundir con el package.json, en la carpeta angular-src que se creará luego.
Instalar Nodemon con el comando "npm i -g nodemon".

- Crear un archivo "app.js" en el directorio pricipal del proyecto para el servidor en ExpressJS.
- Crear una carpeta "models" para los modelos que se usarán en el servidor.

* Creación del proyecto Angular:

- Abrir la linea de comando dentro del directorio del proyecto
- Ejecutar el comando: ng new angular-src, para crear un nuevo projecto Angular en la carpeta angular-src
- Para correr el servidor ejecutar el comando "npm start", dentro de la carpeta raíz del proyecto
- Luego de que finalice la instalacion ejecutar el comando: "npm start" dentro de la carpeta angular-src, para abrir el proyecto Angular en el navegador. El puerto que usa Angular por defecto es el http://localhost:4200/.
