export class Student {
  firstName: string;
  lastName: string;
  id: string;
}
